# Handoff: Discover page redesign (dashapps)

## Overview

Rework of the dashapps **Discover** view (and a new **Category** view) so the registry's
existing data is actually surfaced: real featured apps instead of placeholder cards,
the 16-value `category` taxonomy, `appUrl` promoted to a primary "Launch app" action,
`tagline` as the row description, and `tags` as chips.

No ratings or reviews — they are not in the contract and are out of scope here.

## About the design files

`dashapps Discover Improved.dc.html` in this bundle is a **design reference written in
HTML**, not production code. Do not copy its markup. It is a static, inline-styled
mock of two screens; the real implementation is a diff against the existing React app
in `src/`, reusing the classes already in `src/styles.css`.

Open the file in a browser: option **1a** is Discover (signed in), option **1b** is the
Category view (read-only session).

## Fidelity

**High-fidelity.** Colors, type, radii and spacing were taken from `src/styles.css`, so
almost everything maps to an existing class. Where the mock introduces new sections,
exact values are given below. Match it pixel-for-pixel; deviations are more likely to be
mock errors than intentional.

## What is reused vs. new

Reused as-is (no CSS changes): `.app-shell`, `.topbar`, `.brand`, `.brand-mark`,
`.network-picker`, `.connection`, `.app-nav`, `.store-hero`, `.feature-card`,
`.feature-primary`, `.feature-secondary`, `.eyebrow`, `.link-button`, `.app-mark`
(+ `.large`, `.warm`), `.registry-entry`, `.entry-copy`, `.entry-links`, `.entry-badge`,
`.open-pill`, `.primary-pill`, `.search-field`, `.segment`, `.signed-out-card`,
`.panel`, `.registry-panel`, `footer`.

New CSS needed (5 classes, listed in full under **New CSS** below): `.category-grid`,
`.category-tile`, `.shelf`, `.shelf-card`, `.chip`.

---

## Screens

### 1a — Discover (signed in)

Top-to-bottom order inside `.app-shell`:

1. **Topbar** — unchanged.
2. **`.store-hero`** — unchanged grid (`1.2fr .9fr`, gap 16px, padding `34px 0 30px`).
   - Left column: `.eyebrow` "FEATURED" + `h1` "Built on Dash Platform" — unchanged.
   - `.link-button` "Add an app" top-right — unchanged.
   - **`.feature-card.feature-primary` — content changes.** Today it renders static copy
     ("Discover Platform apps" / "Browse metadata submitted by contract owners and the
     community.") and an `.app-mark.large` reading "D". It should render a real featured
     entry: `.eyebrow` = `<CATEGORY> · OFFICIAL ENTRY`, `h2` = `entry.name`, `p` =
     `entry.tagline`, then a bottom row of `.app-mark.large` (name initial) + a white
     "Launch app ↗" pill (only when `entry.appUrl`) + a translucent "Details" pill.
     - The bottom row is a flex row, `gap: 12px`, replacing `.feature-card .app-mark`'s
       `position: absolute`. Add `.feature-primary { display: flex; flex-direction: column }`
       and put the row in a `div` with `margin-top: auto`.
     - White pill: `border-radius: 999px; padding: 12px 24px; background: #fff; color: #0767cf; font: 700 13px`.
     - Ghost pill: `background: rgba(255,255,255,.16); border: 1px solid rgba(255,255,255,.55); color: #fff`.
   - **`.feature-card.feature-secondary` — content changes.** Today: "Publish app metadata".
     It should become an "ALSO FEATURED" list of three `.registry-entry`-shaped rows
     (48px `.app-mark` / copy / `.open-pill` "Details"), `gap: 14px`, no bottom borders.
3. **`.search-field`** — the existing Search-view component, moved onto Discover.
   Placeholder: "Search app names, or paste a 32-byte contract ID". Submitting routes to
   name search if the value is not a valid 32-byte base58 id (use `parseId`/`requireId`
   from `src/dash/ids.ts`), otherwise straight to detail.
4. **Browse by category** — new section, separated by `border-top: 1px solid #dfe3e8;
   padding: 26px 0`. `.panel-heading`-style header (`h2` 19px + `span` "16 categories"),
   then `.category-grid`: 4 columns, `gap: 10px`, one `.category-tile` per
   `APP_CATEGORIES` entry, in schema order. Each tile is an 8×8px `border-radius: 3px`
   swatch + the label. Labels are `category.replaceAll("-", " ")` with sentence casing —
   see the label table below.
5. **Launchable now** — new section, same separator. Header `span`: "Entries that
   published an app URL". `.shelf`: 4 columns, `gap: 16px`, `.shelf-card` = 58px
   `.app-mark.large`, name (700 14px), tagline (400 13px `#64748b`), a `.chip` with the
   category, and a solid `#0767cf` "Launch app ↗" pill. Cards in this shelf are only
   entries where `appUrl` is set.
6. **Recently added** — the existing `RegistryExplorer` panel, with `Entry` rows changed
   (see **`Entry` component** below). Header `span`: "Newest first". Two-column layout:
   `grid-template-columns: minmax(0,1fr) 300px; gap: 34px`.
   - Right rail: a `.panel` "Describe a contract" (copy: "Paste a contract ID to add your
     entry. One entry per identity per contract.") with an "Add an app" button that calls
     `navigate("add")`; below it "Popular tags" as `.chip`s.
7. **`footer`** — unchanged.

### 1b — Category view

New view. Reachable from any `.category-tile` and from the category chip on a row.

- `.page-heading` with `.back-link` "← Discover", `.eyebrow` (swatch + "CATEGORY"),
  `h1` = category label, and a `.segment` control on the right: **All / Launchable /
  Official only** (client-side filters over the loaded page — see **Open question**).
- Count line: `"{n} apps in this category"`, 400 12px `#64748b`.
- `.registry-entry` rows, same as Discover but with a third line of tag `.chip`s.
- `.signed-out-card` at the bottom when not signed in: "Know a wallet app that's
  missing?" / "Sign in to describe its contract — one entry per identity." + `.sign-in-pill`.

---

## Code changes by file

### `src/dash/registryReads.ts`

Add one read. The contract already has the index — `byCategoryCreated`
(`category asc`, `$createdAt asc`) — so this needs no contract change:

```ts
export async function entriesByCategory(
  sdk: ReadSdk,
  registryId: string,
  category: AppCategory,
  cursor?: string,
): Promise<{ entries: RegistryEntry[]; cursor?: string }>
```

Model it on `searchEntriesByName` (same page-size, same `startAfter` cursor handling,
same `toDocumentArray` + `registryEntry` mapping). Order by `$createdAt` and reverse for
newest-first display, exactly as `recentEntries` does.

### `src/components/RegistryViews.tsx`

**`Entry` component — the main change.** Today the row body is
`<strong>{name}</strong>`, `<p>{tagline}</p>`, `<small>Submitted by <code>{ownerId}</code></small>`,
then a flat run of `<a>` links. Change to:

- Line 1: name, then badges — `.entry-badge` "Official entry" when
  `entry.ownerId === contractOwnerId`, "Your entry" when `entry.ownerId === session.identityId`
  (amber variant, see New CSS), "Community entry" otherwise; plus a `.chip` for the category.
- Line 2: `entry.tagline` + `·` + `<DpnsName identityId={entry.ownerId} resolver={connection.names} />`.
  Drop the raw `<code>{ownerId}</code>` — `DpnsName` already exists in
  `src/components/DpnsName.tsx` and falls back to a shortened id.
- Line 3 (Category view only): tag `.chip`s from `entry.tags`.
- Actions: `appUrl` becomes a solid `#0767cf` "Launch ↗" pill (currently a plain
  `.entry-links a`); `.open-pill` "Details" always; "Edit" (`.muted-pill`) when the entry
  is the signed-in identity's. Website/Repository/Docs links move off the row into detail —
  they crowd it once badges and category are present.
- `.app-mark` keeps its current behavior: `entry.name.slice(0,1).toUpperCase()`.
  Do **not** start rendering `iconUrl` (see **Deliberately unchanged**).

**`RegistryExplorer`** — accept an optional right-rail `children`/`aside` prop so
Discover can render the "Describe a contract" panel beside the list, and allow a
`heading`/`subheading` override so the panel header can read "Recently added / Newest first".

**New `CategoryBrowser`** component (or a `mode: "category"` on `RegistryExplorer`,
whichever is less invasive): holds `category`, calls `entriesByCategory`, owns the
All/Launchable/Official segment state, renders `Entry` rows.

### `src/App.tsx`

- Extend `View`: `type View = "discover" | "search" | "mine" | "settings" | "add" | "category"`,
  and hold `const [category, setCategory] = useState<AppCategory>()`. Include `category`
  in the `Browser` remount key so a switch resets in-flight reads, same as the other views.
- **Featured entries.** Discover needs 1 hero + 3 secondary entries before the "Recently
  added" list loads. Cheapest correct source: the curated seeds in
  `src/dash/systemContractMetadata.ts` — `SYSTEM_CONTRACT_METADATA` is installed into every
  newly published registry, so those contract ids are present. Resolve them with
  `exactRegistryEntry(sdk, registryId, <seed owner>, contractId)`, or simply take the first
  four entries whose `appUrl` is non-empty from the `recentEntries` page and fall back to the
  seeds. Prefer DashPay for the hero: it is the one seed with a non-empty `appUrl`.
- **Launchable shelf** — filter the loaded `recentEntries` page on `entry.appUrl`. No new read.
- Move the `.search-field` form out of the `view === "search"` guard so it renders on
  Discover too.
- Delete the two static `.feature-card` bodies and render entries instead.

### `src/styles.css`

Append the new classes; change nothing existing except adding
`display: flex; flex-direction: column` to `.feature-primary` (see above).

---

## New CSS

```css
.category-grid,
.shelf {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(4, minmax(0, 1fr));
}
.shelf {
  gap: 16px;
}
.category-tile {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 14px 16px;
  border: 0;
  border-radius: 15px;
  background: #f3f4f6;
  color: #111827;
  font-size: 13px;
  font-weight: 700;
  text-align: left;
}
.category-tile span {
  width: 8px;
  height: 8px;
  border-radius: 3px;
  flex: none;
}
.shelf-card {
  display: flex;
  flex-direction: column;
  gap: 13px;
  padding: 22px;
  border: 1px solid #dfe3e8;
  border-radius: 16px;
}
.chip {
  display: inline-block;
  border-radius: 999px;
  padding: 5px 9px;
  background: #f1f3f6;
  color: #334155;
  font-size: 11px;
  font-weight: 700;
}
.entry-badge.own {
  background: #fff4e5;
  color: #8a5a05;
}
.entry-badge.missing {
  background: #fff0ef;
  color: #9f261d;
}
@media (max-width: 760px) {
  .category-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .shelf { grid-template-columns: 1fr; }
}
```

Category swatch colors, in `APP_CATEGORIES` order — all drawn from values already in
`styles.css` except the four noted:

| category | label | swatch |
| --- | --- | --- |
| `finance` | Finance | `#0767cf` |
| `wallets-payments` | Wallets & payments | `#1889df` |
| `social` | Social | `#6d45d6` * |
| `messaging` | Messaging | `#b14fa8` * |
| `games` | Games | `#b42318` |
| `marketplaces` | Marketplaces | `#c2660a` * |
| `productivity` | Productivity | `#087942` |
| `developer-tools` | Developer tools | `#15955d` |
| `data-analytics` | Data & analytics | `#0e7c86` * |
| `identity` | Identity | `#8a5a05` |
| `governance-community` | Governance & community | `#526077` |
| `media` | Media | `#9f261d` |
| `education` | Education | `#084588` |
| `utilities` | Utilities | `#475569` |
| `infrastructure` | Infrastructure | `#39445a` |
| `other` | Other | `#94a3b8` |

\* new values; the rest already exist in `styles.css`.

---

## Design tokens (all pre-existing in `src/styles.css`)

- Accent `#0767cf`; accent gradient `linear-gradient(145deg, #0767cf, #084588)`
- Ink `#111827`; secondary text `#64748b`; nav idle `#39445a`; chip text `#334155`
- Borders `#dfe3e8` (cards), `#e7e9ed` (row rules), `#e8ebef` (topbar)
- Surfaces `#fff`, `#f3f4f6`, `#f1f3f6`, `#eef1f5` (pills), `#eef0f3` (segment track)
- `.app-mark` gradient `linear-gradient(145deg, #6fcaf5, #1889df)`, `.warm`
  `linear-gradient(145deg, #ffc76e, #ff8a2b)`, shadow `0 5px 12px rgba(16,112,203,.18)`
- Success `#087942` on `#eaf8f0`, dot `#12ad66`; error `#9f261d` on `#fff0ef`
- Radii: 999px pills, 11px shell, 13px `.app-mark`, 15px `.app-mark.large` / tiles,
  16px cards, 18px feature cards
- Type: Inter — 28px/-.035em h1, 23px feature h2, 19px panel h2, 14px/700 row title,
  13px body, 12px pills, 11px/800/.04em eyebrow
- Gutters 36px (18px under 760px); shell `max-width: 1220px`

## Behavior

- **Launch app** — `<a target="_blank" rel="noreferrer">` to `entry.appUrl`, rendered only
  when set. Everything else uses **Details**, which is the existing `open(id, name)` →
  `inspect()` path.
- **Category tile** → `navigate("category")` + `setCategory(...)`. Back link returns to Discover.
- **Segment filters** are client-side over the loaded page; label them so they don't imply
  a complete set.
- **Loading** — keep the existing `role="status"` "Loading registry…" text. Featured cards
  should render their frame with the copy area empty rather than collapsing.
- **Errors** — unchanged `.error` `role="alert"` blocks; a failed featured read should
  degrade to the current static card, not blank the hero.
- **Read-only** — no Edit actions, `.signed-out-card` prompt at the end of the list.
- **Responsive** — as in the media query above; `.registry-entry` already reflows.

## Deliberately unchanged

- **`iconUrl` is not rendered.** It is in the schema (HTTPS-only, position 10) and the
  seeds set it, but the field's own help text says dashapps does not load the URL, so all
  tiles stay `.app-mark` monograms. Rendering remote icons is a separate decision — it
  means third-party requests from arbitrary submitters, and needs a loading/broken state
  and probably a proxy or allowlist. Ask before building it.
- **No ratings/reviews** anywhere.
- Detail, Search, Mine and Settings views are untouched by this handoff.

## Open questions for whoever implements this

1. **"Popular tags"** has no index behind it. `tags` is a comma string (max 5, pattern
   `^[a-z0-9-]+(,[a-z0-9-]+){0,4}$`) with no index in `APP_METADATA_SCHEMAS`, so the rail
   can only tally tags from entries already loaded. Either label it honestly ("From recent
   entries") or drop the section. Do not imply a global ranking.
2. **Newest-first ordering.** The `recent` index is `$createdAt: asc`; the current code
   reverses it. The plan lists descending order / cursor continuation on `recent` as
   unverified against testnet. If it does not hold, "Recently added / Newest first" needs
   softer wording — the same caveat applies to `entriesByCategory`.
3. **Featured selection** is unspecified beyond "prefer a seeded entry with an `appUrl`".
   If curation matters, it wants an explicit list somewhere rather than "first four".

## Files in this bundle

- `dashapps Discover Improved.dc.html` — the design reference (1a Discover, 1b Category)
- `README.md` — this guide
